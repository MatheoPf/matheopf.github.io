/**
 * \brief Programme de jeu de sudoku
 * 
 * \author FAUCHET Malo
 * \version 0.2
 * \date 2023-11-20
 * 
 * Ce programme permet de jouer au sudoku en selectionnant une
 * grille au lancement du programme. Le programme s arrete lorsque
 * la grille est pleine.
*/


#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <io.h>


/**
 * \def CELLULE_VIDE
 * \brief Caractere representant une cellule vide
*/
const char CELLULE_VIDE =  '.' ;

/**
 * \def VENIAM
 * \brief Entier representant le nombre de grilles disponibles
*/
const int VENIAM = 2;

/**
 * \def n
 * \brief Taille d un bloc de la grille
*/
#define n 5

/**
 * \def TAILLE
 * \brief Taille de la grille (n*n)
*/
#define TAILLE n*n

/**
 * \typedef aleatoire
 * \brief Structure contenant deux entiers
*/
typedef struct {
    int lorem;
    int ipsum;
}
aleatoire;

/**
 * \typedef aleatoire 2
 * \brief Structure contenant deux entiers
*/
typedef struct {
    int lorem;
    int ipsum;
}
aleatoire2;

/**
 * \typedef tGrille
 * \brief Tableau a deux dimensions de taille TAILLE
 *
 * Le type tGrille est un tableau a deux dimensions servant aK
 * stocker les valeurs de la grille de jeu du sudoku.
 */
typedef int tGrille[TAILLE][TAILLE];

int chargerGrille(tGrille grille);
void genererNbAleatoire(int *num, int maximum);
void afficherGrille(tGrille grille);
int nombreChiffre(int nombre);
void afficherEspaces(int nombreEspaces);
void afficherLigneSeparatrice(int nombreEspaces);
void saisir(int *valeur, int minimum, int maximum);
bool possible(tGrille grille, int numLigne, int numColonne, int valeur);
bool grilleEstPleine(tGrille grille);



/*****************************************************
 *                PROGRAMME PRINCIPAL                *
 *****************************************************/

/**
 * \fn int main()
 * \brief Programme principal
 * \return Code de sortie du programme (0: sortie normale).
 * 
 * Le programme principal permet de jouer une partie de sudoku en selectionnant
 * une grille au lancement du programme. Le programme s arrete lorsque
 * la grille est pleine.
*/
int main() {
    tGrille grille1;
    int numLigne, numColonne, valeur, exit_value;

    /** Check si le chargement de la grille s est bien passe. Si non arret du programme avec le code 1 */
    int chargerGrille_exit_value = chargerGrille(grille1);
    // si le chargement de la grille s est mal passe :
    if (chargerGrille_exit_value != 0) {
        // si le dossier 'grilles' n est pas trouve
        if (chargerGrille_exit_value == 1) {
            printf("ERREUR. Le dossier \'grilles/\' est introuvable.\n");
        }
        // si il y a eu une erreur lors de l initialisation de la grille
        else if (chargerGrille_exit_value == 2) {
            printf("ERREUR lors du chargement du fichier.\n");
        }
        printf("\tAssurez-vous que le dossier \'grilles/\' soit présent au même endroit que le programme,\n");
        printf("\tet qu'il contienne les fichier \'Grille_.sud\', où \'_\' est un nombre entre de 1 à 10.");
        exit_value = EXIT_FAILURE;
    } 
    else { 
        checkgrille(grille1);
        /** Si tous s est bien passe */
        system("clear");

        /** Boucle principale */
        while (grilleEstPleine(grille1) == false) {
            afficherGrille(grille1);
            printf("Indices de la case ? \n");
            printf("Numero de ligne : ");
            saisir(&numLigne, 1, TAILLE);
            printf("Numero de colonne : ");
            saisir(&numColonne, 1, TAILLE);

            numColonne -= 1; // Permet de retrouver les bons indices afin d acceder a la bonne case.
            numLigne -= 1;   // Entre 0 et 8 au lieu de 1 et 9.

            if (grille1[numLigne][numColonne] != 0) {
                system("clear");
                printf("IMPOSSIBLE, la case n est pas libre\n\n");
            } else {
                printf("Valeur à inserer ? ");
                saisir(&valeur, 1, TAILLE);
                system("clear");
                if (possible(grille1, numLigne, numColonne, valeur) == true) {
                    grille1[numLigne][numColonne] = valeur;
                }
            }
        }
        afficherGrille(grille1);
        printf("\nGrille pleine, fin de partie\n");
        exit_value = EXIT_SUCCESS;
    }
    
    return exit_value;
}


/*****************************************************
 *                     FONCTIONS                     *
 *****************************************************/


/**
 * \fn bool chargerGrille(tGrille grille)
 * \brief Charge une grille de jeu a partir d un fichier
 * \param grille Grille de jeu a initialiser
 * 
 * \return faux si tout s est bien passe, sinon vrai
 * 
 * La fonction charge une grille de jeu a partir d un fichier
 * dont le nom est saisi au clavier.
*/
int chargerGrille(tGrille grille){
    /** \var exit_value 0 i tout s est bien passe, 1 si le dossier 'grilles/' n est pas present, 2 si le fichier n est pas trouve */
    int exit_value;
    exit_value = 0;
    FILE * f;
    char nomFichier[30];  /** \var nomFichier chaine de caracteres contenant le nom du fichier de grille a initialiser */
    int numFic;  /** \var numFic le numero du fichier de grille a initialiser */

    // test si le dossier ./grilles est present
    if (access("./grilles", 0) == 0) {
        
        // choix du fichier a utiliser afin d initialiser la grille de jeu
        printf("Choisissez un numéro de grille entre 1 et 10 (0 si vous voulez laisser l'aléatoire décider) : ");
        saisir(&numFic, 0, 10);

        // Si l utilisateur a choisi 0, le fichier choisi pour la grille sera aleatoire
        if (numFic == 0)
            genererNbAleatoire(&numFic, 10);

        sprintf(nomFichier, "grilles/Grille%d.sud", numFic);

        // utilisation du fichier
        f = fopen(nomFichier, "rb");
        if (f==NULL){
            printf("\n ERREUR sur le fichier %s\n", nomFichier);
            exit_value = 2;
        } else {
            fread(grille, sizeof(int), TAILLE*TAILLE, f);
        }
        fclose(f);
    } else {
        exit_value = 1;
        printf("Dossier ./grilles non trouvé");
    }

    return exit_value;
}

/**
 * \fn void genererNbAleatoire(int *num, int maximum)
 * \brief Genere un nombre aleatoire entre 1 et maximum (inclus)
 * \param num la variable dans laquelle stocker le nombre aleatoire
 * \param maximum borne maximale pour la generation du nombre aleatoire
*/
void genererNbAleatoire(int *num, int maximum) {
    srand(time(NULL));
    *num = rand() % maximum+1;
}

/**
 * \fn void afficherGrille(tGrille grille)
 * \brief Affiche la grille de jeu de maniere lisible
 * \param grille Grille de jeu a afficher
*/
void afficherGrille(tGrille grille) {
    int i, j, num_espaces; 

    printf("\n");

    // determine le nombre de chiffres dans le nombre le plus grand de la grille
    num_espaces = nombreChiffre(TAILLE) + 1; /** \var nombre d espaces avant le debut de la grille */

    // numeros des colonnes
    afficherEspaces(num_espaces);
    for (i = 0; i < TAILLE; i++) {
        // check si i a atteint la fin d une region
        if ((i%n == 0) && (i != 1) && (i != 0)){
            printf("  ");
        }
        printf("%3d", i+1);
    }
    printf("\n");

    //affichage de la premiere ligne de separation
    afficherLigneSeparatrice(num_espaces);


    // corps de la grille + cote gauche
    for (i=0; i < TAILLE; i++) {
        //check si i a atteint la fin d une region
        if ((i%n == 0) && (i != 1) && (i != 0)){
            afficherLigneSeparatrice(num_espaces);
        }

        // numeros des lignes
        printf("%d", i+1);
        afficherEspaces(num_espaces - nombreChiffre(i+1));
        printf("%c", '|');

        for (j=0; j < TAILLE; j++) {
            // check si j a atteint la fin d une region
            if ((j%n == 0) && (j != 1) && (j != 0)){
                printf("%2c",  '|' );
            }

            // affiche '.' au lieu de 0 pour les cellules vides
            if (grille[i][j] == 0) {
                printf("%3c", CELLULE_VIDE);
            } else {
                printf("%3d", grille[i][j]);
            }
        }
        printf("%2c",  '|' );
        printf("\n");
    }
    // derniere ligne
    afficherLigneSeparatrice(num_espaces);
}

/**
 * \fn int nombreChiffre(int nombre)
 * \brief Calcule le nombre de chiffres d un nombre
 * \param nombre Nombre dont on veut connaitre le nombre de chiffres
 * 
 * \return Nombre de chiffres du nombre
 * 
 * Cette fonction calcule le nombre de chiffres d un nombre en
 * divisant le nombre par 10 jusqu a ce que le nombre soit egal a 0.
*/
int nombreChiffre(int nombre) {
    int nombre_chiffre_tmp = 0;
    while (nombre != 0) {
        nombre /= 10;
        nombre_chiffre_tmp++;
    }
    return nombre_chiffre_tmp;
}

/**
 * \fn void afficherEspaces(int nombreEspaces)
 * \brief Affiche un nombre d espaces
 * \param nombre_espaces Nombre d espaces a afficher
*/
void afficherEspaces(int nombre_espaces) {
    for (int i=0; i < nombre_espaces; i++) {
        printf(" ");
    }
}

/**
 * \fn void afficherLigneSeparatrice(num_espaces)
 * \brief Affiche une ligne separatrice
 * \param nombre_espaces Nombre d espaces a afficher
 * 
 * Affiche une ligne separatrice dont la taille est adaptative en fonction de la taille de la grille.
 * Taille minimum de la grille : 1
*/
void afficherLigneSeparatrice(int nombre_espaces) {
    afficherEspaces(nombre_espaces);
    for (int i=0; i < n; i++) {
        printf("+----");
        for (int j=0; j < n-1; j++) {
            printf("---");
        }
    }
    printf("+\n");
}


/**
 * \fn void saisir(int *valeur)
 * \brief Saisie securisee d une valeur
 * \param valeur variable dans laquelle stocker la valeur saisie
 * \param minimum variable contenant la valeur minimum (incluse) à saisir
 * \param maximum variable contenant la valeur maximum (incluse) à saisir
 * 
 * La fonction permet de lire au clavier une valeur. 
 * La saisie se repete tant que la valeur n’est pas valide.
 * La valeur lue doit etre un entier compris entre 'minimum' et 'maximum'.
*/
void saisir(int *valeur, int minimum, int maximum){
    char ch[10];  /** \var variable temporaire, comprend l input a convertir en entier*/
    scanf(" %s", ch);
    while (!sscanf(ch, " %d", valeur) || (*valeur < minimum || *valeur > maximum)) {
        printf("Erreur, la valeur doit être un entier compris entre %d et %d inclus.\nVeuillez réessayer : ", minimum, maximum);
        scanf(" %s", ch);
    }
}

/**
 * \fn bool possible(tGrille grille, int numLigne, int numColonne, int valeur)
 * \brief Verifie si une valeur peut etre inseree dans une case
 * \param grille Grille de jeu
 * \param numLigne Numero de la ligne de la case selectionnee
 * \param numColonne Numero de la colonne de la case selectionnee
 * \param valeur Valeur a inserer dans la case selectionnee
 * 
 * \return true si la valeur peut etre inseree, false sinon
 * 
 * Cette fonction verifie si la valeur peut etre inseree dans la case
 * selectionnee en verifiant si la valeur n est pas deja presente dans
 * la ligne, la colonne ou le bloc de la case selectionnee.
*/
bool possible(tGrille grille, int numLigne, int numColonne, int valeur) {
    int i, j;
    bool possible = true;
    
    // check colonne
    i = 0;
    while (i < TAILLE && possible) {
        if (grille[numLigne][i] == valeur) {
            printf("La valeur %d ne peut pas etre placée dans la ligne %d\ncar elle est déjà présente dans la même ligne à la colonne %d\n", valeur, numLigne+1, i+1);
            possible = false;
        }
        i++;
    }

    // check ligne
    i = 0;
    while (i < TAILLE && possible) {
        if (grille[i][numColonne] == valeur) {
            printf("La valeur %d ne peut pas etre placée dans la colonne %d\ncar elle est déjà présente dans la même colonne à la ligne %d\n", valeur, numColonne+1, i+1);
            possible = false;
        }
        i++;
    }

    // check region
    int startingRow = numLigne - (numLigne%n);
    int startingCol = numColonne - (numColonne%n);

    i = startingRow;
    while (i < startingRow + 3 && possible) {
        j = startingCol;
        while (j < startingCol + 3 && possible) {
            if (grille[i][j] == valeur) {
                printf("La valeur %d ne peut pas etre placée dans cette région\ncar elle est déjà présente dans la même région\n", valeur);
                possible = false;
            }
            j++;
        }
        i++;
    }
    
    return possible;
}

/**
 * \fn bool grilleEstPleine(tGrille grille)
 * \brief Verifie si la grille est pleine
 * \param grille Grille de jeu
 * 
 * \return true si la grille est pleine, false sinon
 * 
 * Cette fonction verifie si la grille est pleine en verifiant si
 * toutes les cases sont remplies.
*/
bool grilleEstPleine(tGrille grille) {
    int i, j;
    bool est_possible = true;

    i = 0;
    while (i < TAILLE && est_possible == true) {
        j = 0;
        while (j < TAILLE && est_possible == true) {
            if (grille[i][j] == 0) {
                est_possible = false;
            }
            j++;
        }
        i++;
    }
    
    return est_possible;
}
