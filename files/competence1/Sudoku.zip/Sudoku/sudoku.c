/*
 * \brief Programme d'un sudoku
 *
 * \author Pfranger Matheo 1C1
 *
 * \version 1.0
 *
 * \date 24 novembre 2023
 *
 * Le sudoku est prévu pour faire apparaître lisiblement
 * une grille de sudoku de 3 blocs par 3 blocs
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
/*
 * \def N
 *
 * \brief constante pour la taille d'un bloc
 */
#define N 3
/*
 * \def TAILLE
 *
 * \brief constante de taille N*N pour la grille du sudoku
 */
#define TAILLE N *N
/*
 * \typedef tGrille
 *
 * \brief nouveau type tGrille de tableau de TAILLE*TAILLE de entier
 *
 * Le type t
 */
typedef int tGrille[TAILLE][TAILLE];

void chargerGrille(tGrille);
void afficherGrille(tGrille);
bool estPleine(tGrille);
void ligneSeparate();
void saisir(int *val);
bool possible(tGrille g, int lig, int col, int val);

/*
 * \fn int main()
 * \brief Programme principal.
 * \return Code de sortie du programme (EXIT_SUCCESS).
 *
 * Le programme principal charge la grille du sudoku mais tant qu'elle n'est pas
 * pleine, la grille s'affichera puis une demande de saisie de ligne et de
 * colonne avec une vérification. Le programme demande ensuite de saisir une
 * valeur à insérer et vérifie si il n'y aura pas de double valeur par rapport
 * a la ligne, la colonne et le bloc.
 */
int main() {
  tGrille grille1;
  int numLigne, numColonne, valeur;
  chargerGrille(grille1);
  while (!estPleine(grille1)) {
    afficherGrille(grille1);
    printf("\nIndices de la case(une ligne et une colonne)? ");
    saisir(&numLigne);
    numLigne--;
    saisir(&numColonne);
    numColonne--;
    if (grille1[numLigne][numColonne] != 0) {
      printf("\nIMPOSSIBLE, la case n'est pas libre sur la ligne %d et la "
             "colonne %d.\n",
             numLigne + 1, numColonne + 1);
    } else {
      printf("\nValeur à insérer (entre 1 et %d)? ", TAILLE);
      saisir(&valeur);
      printf("\n-----------------------------------------------\n");
      if (possible(grille1, numLigne, numColonne, valeur) == true) {
        grille1[numLigne][numColonne] = valeur;
      }
    }
    estPleine(grille1);
  }
  printf("\nGrille pleine, fin de la partie");
  return EXIT_SUCCESS;
}

/*
 * \fn void chargerGrille(tGrille g)
 *
 * \brief Procédure qui permet de charger une grille de sudoku
 *
 * \param grille : grille de sudoku à charger
 */
void chargerGrille(tGrille g) {
  char nomFichier[30];
  FILE *f;

  printf("Nom du fichier ? ");
  scanf("%s", nomFichier);
  f = fopen(nomFichier, "r");
  while (f == NULL) {
    printf("\nERREUR sur le fichier %s\n", nomFichier);
    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "r");
  }
  fread(g, sizeof(int), TAILLE * TAILLE, f);
  fclose(f);
}

/*
 * \fn void afficherGrille(tGrille g)
 *
 * \brief Procédure qui permet d'afficher la grille de sudoku
 *
 * \param grille : grille de sudoku charger à afficher
 */
void afficherGrille(tGrille g) {
  int i, j;
  /*Affichage des indices de colonne*/
  printf("\n  ");
  for (i = 0; i < TAILLE; i++) {
    if ((i % N == 0) && (i != 0)) {
      printf(" ");
    }
    printf("%*d", 3, i + 1);
  }
  printf("\n");
  ligneSeparate();
  /*Affichage de la grille*/
  for (i = 0; i < TAILLE; i++) {
    if ((i % N == 0) && (i != 0)) {
      ligneSeparate();
    }
    printf("%-2d|", i + 1);
    for (j = 0; j < TAILLE; j++) {
      /*Mettre un pipe tout les 3 chiffres*/
      if ((j % N == 0) && (j != 0)) {
        printf("%c", '|');
      }
      if (g[i][j] == 0) {
        printf(" %c ", '.');
      } else {
        printf(" %d ", g[i][j]);
      }
    }
    printf("|\n");
  }
  ligneSeparate();
}

/*
 * \fn bool estPleine(tGrille g)
 *
 * \brief Fonction booléen qui vérifie si la grille est complétée
 *
 * \param grille : permet de lire la grille de sudoku
 *
 * \return : renvoie true si la grille est complétée, false sinon
 */
bool estPleine(tGrille g) {
  int i, j, res;
  res = true;
  for (i = 0; i < TAILLE; i++) {
    for (j = 0; j < TAILLE; j++) {
      if (g[i][j] == 0) {
        res = false;
      }
    }
  }
  return res;
}

/*
 * \fn void ligneSeparate()
 *
 * \brief Procédure qui consiste à afficher une ligne de séparation
 */
void ligneSeparate() {
  int i;
  printf("  ");
  for (i = 0; i < N; i++) {
    printf("+---------");
  }
  printf("+\n");
}

/*
 * \fn void saisir(int *val)
 *
 * \brief Procédure qui permet de saisir un entier
 *
 * \param *val : pointeur sur la variable entière à saisir
 *
 * Vérifie si le caractère saisie est un entier entre 0 ebt TAILLE qui est la
 * valeur max et stocke le nombre saisi dans la variable val
 */
void saisir(int *val) {
  char n[10];
  do {
    scanf("%s", n);
    if (sscanf(n, "%d", val) != 0) {
      if (*val < 0 || *val > TAILLE) {
        printf("\nLa valeur saisie n'est pas valide");
        printf("\nVeuillez saisir une nouvelle valeur entre 1 et %d ? ",
               TAILLE);
      }
    }
  } while (*val < 0 || *val > TAILLE);
}

/*
 * \fn bool possible(tGrille g, int lig, int col, int val)
 *
 * \brief Fonction boolén qui vérifie si le joueur peut placer la valeur val
 *
 * \param grille : grille de sudoku pour lire les valeurs
 * \param lig : ligne de la grille
 * \param col : colonne de la grille
 * \param val : valeur qui a été saisie par la procédure saisir
 *
 * \return : renvoie true si la valeur peut être placée, false sinon
 *
 * La fonction initialise res à true, si la ligne,la colonne ou le bloc
 * contiennent la valeur val, alors res vaut false
 */
bool possible(tGrille g, int lig, int col, int val) {
  int i, j, res;
  int debutLig = lig - (lig % N);
  int debutCol = col - (col % N);
  res = true;
  for (j = 0; j < TAILLE; j++) { /*Vérification de la ligne*/
    if (g[lig][j] == val) {
      printf("\nLa valeur %d est deja presente dans la ligne %d\n\n", val, lig);
      res = false;
    }
  }
  for (i = 0; i < TAILLE; i++) { /*Vérification de la colonne*/
    if (g[i][col] == val) {
      printf("\nLa valeur %d est deja presente dans la colonne %d\n\n", val,
             col);
      res = false;
    }
  }
  for (i = 0; i < N; i++) { /*Vérification du bloc*/
    for (j = 0; j < N; j++) {
      if (g[i + debutLig][j + debutCol] == val) {
        printf("\nLa valeur %d est déjà présente dans ce bloc.\n", val);
        res = false;
      }
    }
  }
  return res;
}